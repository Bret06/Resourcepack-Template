# Resourcepack Template Made By Bret06
## Resourcepack Template for Minecraft: Java Edition

[![License: CC BY-NC-SA 4.0](https://img.shields.io/badge/License-CC%20BY--NC--SA%204.0-brightgreen.svg)](https://creativecommons.org/licenses/by-nc-sa/4.0/)

www.bret06.me

This is a free to use resourcepack template for anyone looking to start making resourcepacks!
