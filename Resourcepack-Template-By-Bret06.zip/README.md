# Resourcepack Template Made By Bret06
## Resourcepack Template for Minecraft: Java Edition

www.bret06.net

This is a free to use resourcepack template for anyone looking to start making resourcepacks!
